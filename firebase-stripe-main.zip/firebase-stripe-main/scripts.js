  var firebaseConfig = {
    // FIREBASE CONFIG HERE!
    apiKey: "",
    authDomain: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: "",
    appId: ""
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  
  const createCheckout = () => {
    const amount = document.getElementById('amount').value
    if (amount >= 1000) {
      const request = {amount: amount}
      const checkoutButton = document.getElementById('checkout-button')
      const createStripeCheckout = firebase.functions().httpsCallable('createStripeCheckout')
      const stripe = Stripe('pk_test_51LPSEpK4n5nurOQY58nM3QSkfbGfdtR1TC1mnu13HuZKDy01AXksLB12lGrRvCBgWaAKi48zUHHb0E2fD3NpAKao0084Ihskjk')
      createStripeCheckout(request)
        .then(response => {
          const sessionId = response.data.id
          stripe.redirectToCheckout({ sessionId: sessionId })
        })
    } else {
      const output = "1,000円以上で金額を設定してください。";
      document.getElementById("output-message").innerHTML = output;
    }
  }