const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.createStripeCheckout = functions.https.onCall(async (data, context) => {
  // Stripe init
  const amount = data.amount;
  // お客様が受け取る手数料です。(feeを20%に設定した場合、コネクトのアカウントは80%受け取ります。)
  const fee = Math.round(amount*0.2);
  const stripe = require("stripe")(functions.config().stripe.secret_key);
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    mode: "payment",
    // 成功時の表示用URLです
    success_url: "https://stripec-test.web.app/success.html",
    cancel_url: "https://stripec-test.web.app/",
    payment_intent_data: {
      application_fee_amount: fee,
      transfer_data: {
        // 振り分けるアカウントごとにIDを変更してください。
        destination: "acct_1LVg4VLqKfM9cECT",
      },
    },
    line_items: [
      {
        quantity: 1,
        price_data: {
          currency: "jpy",
          unit_amount: amount,
          product_data: {
            name: "Destination",
          },
        },
      },
    ],
  });
  const id = session.id;
  return {
    id: id,
  };
});
